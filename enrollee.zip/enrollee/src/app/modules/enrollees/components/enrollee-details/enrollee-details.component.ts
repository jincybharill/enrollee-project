import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EnrolleeService } from '../../services/enrollee.service';
import { Enrollee } from '../../../../classes/enrollee';

@Component({
  selector: 'app-enrollee-details',
  templateUrl: './enrollee-details.component.html',
  styleUrls: ['./enrollee-details.component.scss']
})
export class EnrolleeDetailsComponent implements OnInit {

  //
  // ─── Public Fields ───────────────────────────────────────────────────────────
  //
  public enrolleeDetails: Enrollee;
  public message: string = '';
  public error: boolean = false;

  constructor(private activatedRoute: ActivatedRoute, private enrolleeService: EnrolleeService) { }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    this.getEnrolleeDetails(id);
  }

  //
  // ─── Private Methods ───────────────────────────────────────────────────────────
  //

  // load selected enrollee
  private getEnrolleeDetails(id: string): void {
    this.enrolleeService.getEnrolleeDetails(id)
      .subscribe((data: Enrollee) => {
        this.enrolleeDetails = data;
      })
  }

  //
  // ─── Public Methods ───────────────────────────────────────────────────────────
  //

  //update selected enrollee
  public updateDetails(): void {
    this.enrolleeService.updateEnrolleDetails(this.enrolleeDetails)
      .subscribe((data: any) => {
        if (data.errorMessage) {
          this.error = true;
          this.message = data.errorMessage;
        }
        else {
          this.enrolleeDetails = data;
          this.error = false;
          this.message = 'Details Updated Successfully!!!';
        }
      })
  }

}
