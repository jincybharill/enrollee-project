import { Component, OnInit } from '@angular/core';
import { EnrolleeService } from '../../services/enrollee.service';
import { Enrollee } from '../../../../classes/enrollee';

@Component({
  selector: 'app-enrollee-list',
  templateUrl: './enrollee-list.component.html',
  styleUrls: ['./enrollee-list.component.scss']
})
export class EnrolleeListComponent implements OnInit {

  //
  // ─── Public Fields ───────────────────────────────────────────────────────────
  //

  public enrolleeList: Enrollee[];

  constructor(private enrolleeService: EnrolleeService) { }

  ngOnInit() {
    this.getEnrollees();
  }

  //
  // ─── Private Methods ───────────────────────────────────────────────────────────
  //

  // Function to load list of enrollees
  private getEnrollees(): void {
    this.enrolleeService.getEnrollees()
      .subscribe((data: Enrollee[]) => {
        this.enrolleeList = data;
      })
  }

}