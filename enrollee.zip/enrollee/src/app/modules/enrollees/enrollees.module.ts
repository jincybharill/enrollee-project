import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { EnrolleeListComponent } from './components/enrollee-list/enrollee-list.component';
import { EnrolleeDetailsComponent } from './components/enrollee-details/enrollee-details.component';
import { RouterModule, Routes } from '@angular/router';
import { EnrolleeService } from './services/enrollee.service';

const routes: Routes = [
  {
    path: '',
    component: EnrolleeListComponent
  },
  {
    path: ':id',
    component: EnrolleeDetailsComponent
  }]

@NgModule({
  declarations: [EnrolleeListComponent, EnrolleeDetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    EnrolleeService
  ]
})
export class EnrolleesModule { }
