import { Injectable } from '@angular/core';
import { EnrolleeApiService } from '../../../services/enrollee-api.service';

@Injectable()
export class EnrolleeService {

  constructor(private apiService: EnrolleeApiService) { }

  //
  // ─── Public Methods ───────────────────────────────────────────────────────────
  //
  public getEnrollees() {
    return this.apiService.getEnrollees();
  }

  public getEnrolleeDetails(id) {
    return this.apiService.getEnrolleeDetails(id);
  }

  public updateEnrolleDetails(details) {
    return this.apiService.updateDetails(details);
  }
}
