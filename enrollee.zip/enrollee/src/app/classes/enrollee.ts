export class Enrollee {
    public id: string;
    public name: string;
    public dateOfBirth: string;
    public active: boolean;
}
