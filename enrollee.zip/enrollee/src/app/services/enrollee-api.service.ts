import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';

import { EndpointService } from '../services/endpoint.service';
import { of, Observable } from 'rxjs';
import { Enrollee } from '../classes/enrollee';

@Injectable({
  providedIn: 'root'
})
export class EnrolleeApiService {

  constructor(private http: HttpClient, private eps: EndpointService) {

  }

  //
  // ─── Public Methods ───────────────────────────────────────────────────────────
  //

  //api call to get list of enrolless
  public getEnrollees(): Observable<Enrollee[]> {
    const url = this.eps.getEnrollees();
    return this.http.get(url).pipe(
      map((data: Enrollee[]) => {
        return data;
      }),
      catchError(error => {
        // return empty array in case of any error
        return of([]);
      })
    )
  }

  //api call to get enrolless details
  public getEnrolleeDetails(id: string): Observable<Enrollee | object> {
    const url = this.eps.getEnrolleeById(id);
    return this.http.get(url).pipe(
      map((data: Enrollee) => {
        return data;
      }),
      catchError(error => {
        // return empty object in case of any error
        return of({});
      })
    )
  }

  //api call to update enrolless
  public updateDetails(details: Enrollee): Observable<Enrollee | object> {
    const url = this.eps.getEnrolleeById(details.id);
    const payload = {
      name: details.name,
      dateOfBirth: details.dateOfBirth,
      active: details.active

    }
    return this.http.put(url, payload).pipe(
      map((data: Enrollee) => {
        return data;
      }),
      catchError(error => {
        // return error message in case of any error
        const message = "Failed to Update"
        return of({ errorMessage: message });
      })
    )
  }

}
