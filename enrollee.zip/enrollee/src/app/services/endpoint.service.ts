
import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';

@Injectable()
export class EndpointService {

    //
    // ─── Private Fields ───────────────────────────────────────────────────────────
    //
    private baseUrl: string;
    private readonly GET_ENROLLEES = '/enrollees';
    private readonly ENROLLEE_BY_ID = '/enrollees/{id}';

    constructor() {
        this.baseUrl = environment.apiUrl;
    }

    //
    // ─── Public Methods ───────────────────────────────────────────────────────────
    //

    public getEnrollees() {
        return this.baseUrl + this.GET_ENROLLEES;
    }

    public getEnrolleeById(id) {
        let url = this.baseUrl + this.ENROLLEE_BY_ID;
        url = url.split('{id}').join(id)
        return url;
    }
}